CREATE DATABASE  IF NOT EXISTS `db_sorteo_anl` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `db_sorteo_anl`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: db_sorteo_anl
-- ------------------------------------------------------
-- Server version	5.6.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_anl_num_frec`
--

DROP TABLE IF EXISTS `tbl_anl_num_frec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_anl_num_frec` (
  `num` int(11) NOT NULL,
  `id_sort` int(11) DEFAULT NULL,
  `id_time` int(11) DEFAULT NULL,
  `cant_win` int(11) DEFAULT NULL,
  `fech_ym` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_anl_num_frec`
--

LOCK TABLES `tbl_anl_num_frec` WRITE;
/*!40000 ALTER TABLE `tbl_anl_num_frec` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_anl_num_frec` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_anl_num_period_win`
--

DROP TABLE IF EXISTS `tbl_anl_num_period_win`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_anl_num_period_win` (
  `num` int(11) DEFAULT NULL,
  `id_time` int(11) DEFAULT NULL,
  `id_sort` int(11) DEFAULT NULL,
  `ymd_last_win` int(11) DEFAULT NULL,
  `period_win` int(11) NOT NULL,
  `ymd_next_prob_win` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_anl_num_period_win`
--

LOCK TABLES `tbl_anl_num_period_win` WRITE;
/*!40000 ALTER TABLE `tbl_anl_num_period_win` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_anl_num_period_win` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_anl_results_provable`
--

DROP TABLE IF EXISTS `tbl_anl_results_provable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_anl_results_provable` (
  `id` int(11) NOT NULL,
  `ymd_sort` int(11) DEFAULT NULL,
  `id_sort` int(11) DEFAULT NULL,
  `id_time` int(11) DEFAULT NULL,
  `num_to_sort` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_anl_results_provable`
--

LOCK TABLES `tbl_anl_results_provable` WRITE;
/*!40000 ALTER TABLE `tbl_anl_results_provable` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_anl_results_provable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_result_sorteo`
--

DROP TABLE IF EXISTS `tbl_result_sorteo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_result_sorteo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `id_sorteo` int(11) NOT NULL,
  `id_horario` int(11) DEFAULT NULL,
  `num1` int(11) DEFAULT NULL,
  `num2` int(11) DEFAULT NULL,
  `num3` int(11) DEFAULT NULL,
  `num4` int(11) DEFAULT NULL,
  `num5` int(11) DEFAULT NULL,
  `num6` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_IDSORT_idx` (`id_sorteo`),
  KEY `FK_HORARIOSORT_idx` (`id_horario`),
  CONSTRAINT `FK_HORARIOSORT` FOREIGN KEY (`id_horario`) REFERENCES `tbl_sorteo_horarios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_IDSORT` FOREIGN KEY (`id_sorteo`) REFERENCES `tbl_sorteos_cat` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_result_sorteo`
--

LOCK TABLES `tbl_result_sorteo` WRITE;
/*!40000 ALTER TABLE `tbl_result_sorteo` DISABLE KEYS */;
INSERT INTO `tbl_result_sorteo` VALUES (1,'2018-10-24',101,2100,52,0,0,0,0,0);
/*!40000 ALTER TABLE `tbl_result_sorteo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_sorteo_horarios`
--

DROP TABLE IF EXISTS `tbl_sorteo_horarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_sorteo_horarios` (
  `id` int(11) NOT NULL,
  `desc` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_sorteo_horarios`
--

LOCK TABLES `tbl_sorteo_horarios` WRITE;
/*!40000 ALTER TABLE `tbl_sorteo_horarios` DISABLE KEYS */;
INSERT INTO `tbl_sorteo_horarios` VALUES (1100,'11am'),(1500,'3pm'),(2100,'9pm');
/*!40000 ALTER TABLE `tbl_sorteo_horarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_sorteos_cat`
--

DROP TABLE IF EXISTS `tbl_sorteos_cat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_sorteos_cat` (
  `id` int(11) NOT NULL,
  `desc_sorteo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_sorteos_cat`
--

LOCK TABLES `tbl_sorteos_cat` WRITE;
/*!40000 ALTER TABLE `tbl_sorteos_cat` DISABLE KEYS */;
INSERT INTO `tbl_sorteos_cat` VALUES (101,'LA DIARIA'),(103,'PEGA 3'),(106,'LA LOTO');
/*!40000 ALTER TABLE `tbl_sorteos_cat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'db_sorteo_anl'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-24 22:56:14
